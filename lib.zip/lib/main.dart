import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'screens/nav_screen.dart';
import 'theme.dart'; // ✅ Import centralized theme

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.theme, // ✅ Use Global Theme
      home: const SplashScreen(), // ✅ Start with Splash Screen
    );
  }
}

// ✅ **Splash Screen with Fade Transition**
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  SplashScreenState createState() => SplashScreenState();
}

class SplashScreenState extends State<SplashScreen> {
  double _opacity = 0.0;

  @override
  void initState() {
    super.initState();

    // **Gradually fade in the splash screen**
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) {
        setState(() {
          _opacity = 1.0;
        });
      }
    });

    // **Navigate to NavScreen after 3 seconds**
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => const NavScreen(),
            transitionsBuilder: (_, animation, __, child) {
              return FadeTransition(opacity: animation, child: child);
            },
            transitionDuration: const Duration(milliseconds: 700),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedOpacity(
        duration: const Duration(seconds: 2),
        opacity: _opacity,
        child: Container(
          decoration: const BoxDecoration(
            gradient: AppTheme.backgroundGradient, // ✅ Use Global Gradient
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.fitness_center, size: 90, color: AppTheme.gold),
                const SizedBox(height: 20),
                Text(
                  "CashFit",
                  style: GoogleFonts.oswald(
                    fontSize: 38,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.gold,
                    letterSpacing: 1.5,
                    shadows: [
                      Shadow(
                        // Replaced withOpacity(0.5) with withAlpha(128) for ~50% opacity
                        color: AppTheme.gold.withAlpha(128),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  "Your journey to fitness starts here.",
                  style: GoogleFonts.oswald(
                    fontSize: 18,
                    color: Colors.white70,
                  ),
                ),
                const SizedBox(height: 30),
                SizedBox(
                  width: 40,
                  height: 40,
                  child: CircularProgressIndicator(
                    color: AppTheme.gold,
                    strokeWidth: 2.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
